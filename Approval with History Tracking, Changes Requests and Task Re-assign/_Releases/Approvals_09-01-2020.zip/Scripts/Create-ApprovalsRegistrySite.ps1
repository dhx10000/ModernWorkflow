﻿# *************************  CONFIG VALUES ***************************

$adminUrl = "https://m365x867142-admin.sharepoint.com"
$currentUser = "dmitryvo@M365x867142.onmicrosoft.com"
$ppServiceAccount = "ppservice@M365x867142.onmicrosoft.com"

# ********* DO NOT CHANGE (Unless necessary) *********

$templateFileName = "ApprovalsRegistrySite.pnp"
$siteName = "Approvals Registry"
$siteUrl = "https://m365x867142.sharepoint.com/sites/ApprovalsRegistry"
$description = "A service site to manage custom Power Platform-based Approvals"

# ******* END DO NOT CHANGE *******

#****************************  END CONFIG ****************************

#Run script for its current location
$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
$dir = $dir.ToString() + "\"
Set-Location $dir

$siteUrl = $tenantUrl + "/sites/" + $alias

# Connect to SharePoint Online
# This command will prompt the sign-in UI to authenticate
Connect-PnPOnline $adminUrl -UseWebLogin

$msg = "Creating new Communication site: " + $siteName + " <" + $siteUrl + ">"
write-output $msg

# Creat the new "modern" team site
$registrySiteUrl = New-PnPSite -Type CommunicationSite -Title $siteName -Url $siteUrl -Description $description -Owner $currentUser

$msg = "Connecting to site: " + $siteUrl
write-output $msg

Connect-PnPOnline $registrySiteUrl -UseWebLogin

$web = Get-PnPWeb -Includes WebTemplate, Configuration

$msg = "Registering Power Platform service account (" + $ppServiceAccount + ") as Site Owner."
write-output $msg

Add-PnPUserToGroup -Identity $web.AssociatedOwnerGroup -EmailAddress "ppservice@M365x867142.onmicrosoft.com"

$msg = "Creating Approvals Registry list."
write-output $msg

# Creating Approvals Registry list...
Apply-PnPProvisioningTemplate -Path $templateFileName

Disconnect-PnPOnline

$msg = "All done!"
write-output $msg