$siteUrl = "https://m365x774940.sharepoint.com/sites/OPGApprovalsTest3"

$templateFileName = "ApprovalLists.pnp"

#****************************  END CONFIG ****************************

#Run script for its current location
$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
$dir = $dir.ToString() + "\"
Set-Location $dir
  
$msg = "Connecting to the destination site: " + $siteUrl
Write-Output $msg
Write-Output ""

#Connect to target site
Connect-PnPOnline -Url $siteUrl -UseWebLogin

$msg = "Importing template... "
Write-Output $msg

# Apply provisioning template
Apply-PnPProvisioningTemplate -Path $templateFileName -Handlers Lists

$msg = "  Done."
Write-Output $msg
Write-Output ""

$approvalTasksGuid = (Get-PnPList -Identity "Approval Tasks").Id.ToString()
$approvalhistoryGuid = (Get-PnPList -Identity "Approval History").Id.ToString()

$msg = "
Lists created: 
    Title: Approval Tasks
    Guid: " + $approvalTasksGuid + "

    Title: Approval History
    Guid: " + $approvalHistoryGuid

Write-Output $msg          

Disconnect-PnPOnline